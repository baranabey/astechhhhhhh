# niwren-supervizor-bot

Altyapının amacı bir sunucuda birden fazla bot yerine tek bir bot olmasını sağlamaktır şuan botun içinde moderasyon, istatistik ve kayıt olmak üzere 3 bot vardır. 

# Telif
İzinsiz paylaşıldığında telif işlemi uygulanır
Kod sunucularında görürsem telif işlemi uygulanır

## Kurulum

Eğer direk projeyi kurucaksanız tek yapmanız gereken server.js ve komutlar klasöründeki bir kaç dasyayı doldurmak.

```js
server.js
```
## Sıkça Sorulabilicek Sorular


### Kod Dosyalarını Nasıl Kurucam?

Tek yapmanız gereken dosyalardaki ID kısımlarını doldurmak, server.js'ye atılıcak bir kod yoktur.

### Sana bir sorum vardı?

Niwren.#0901 (676128212681490459) Discord hesabıma ulaşabilirsiniz, eğer ulaşamazsanız [discord.gg/serendia](https://discord.gg/serendia)'ya sorun, yol göstereceklerdir.

### Bir hata buldum?

Bana ulaşın, elimden geldiğince hızlı çözerim.

## Serendia Ailesine ve ordan bu altyapıyı isteyenlere Sevgilerle <3
![Serendia](standard_11.gif)

